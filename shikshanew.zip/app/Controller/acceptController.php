<?php
class acceptController extends AppController {

function ready () {
echo $_POST['parameter']; 
}
?>