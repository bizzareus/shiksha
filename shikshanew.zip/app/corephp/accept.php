<?php

echo $_POST['parameter']; 

?>